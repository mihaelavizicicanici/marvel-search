# AngularApp
My First Angular Website with external API, Angular Routing and more.
